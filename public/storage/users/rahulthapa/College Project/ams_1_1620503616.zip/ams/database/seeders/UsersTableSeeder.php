<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name'=>'Bright Office',
            'email'=>'admin@myself.com',
            'password'=>Hash::make('ajakcha123'),
            'address'=>'Butwal-03, Golpark',
            'number'=>'071000000',
            'role_id'=>1
        ]);
    }
}
